from django.conf.urls import url, include
from users import user

urlpatterns = [
    url(r'^user/', include([
        url(r'^list/$', user.UserList.as_view(), name="user_lsit"),

    ]))
]