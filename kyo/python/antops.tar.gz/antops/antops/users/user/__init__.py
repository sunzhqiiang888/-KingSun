from django.shortcuts import redirect
from django.http import QueryDict, HttpResponse
from django.views.generic import TemplateView, View, ListView
from django.contrib.auth.mixins import LoginRequiredMixin
from users.models import UserProfile




class UserList(ListView):
    template_name = "users/user/user_list.html"
    model = UserProfile