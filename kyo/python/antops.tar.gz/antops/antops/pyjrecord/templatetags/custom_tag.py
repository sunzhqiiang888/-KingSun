# -*- coding:utf-8 -*-
from __future__ import (
    unicode_literals, print_function, division, absolute_import
)
from django import template

register = template.Library()


@register.filter
def deal_pyj(res):
    if res:
        return (res.split(":"))[-1]
    else:
        return u''

