# -*- coding:utf-8 -*-
import pymysql
from django.views.generic import TemplateView

# m默认为运维db
client_db = {
    "db_host": "39.108.108.30",
    "db_port": "3306",
    "db_name": "yw_asset",
    "db_user": "yw_portal_user",
    "db_pass": "cMnd&^dhG$dg6"
}


class DownLoadRecord(TemplateView):
    template_name = "pyjrecord/reocrd/pyjrecord_list.html"

    def get_context_data(self, **kwargs):
        context = super(DownLoadRecord, self).get_context_data(**kwargs)

        # sql = "select id,app_name from gameinfo where role=1 and game_type=1 and merged=0"
        sql = "select id,app_name from gameinfo where game_type=1 and role=1 and merged=0 and recover_status=0"
        try:
            res_data = self.read_data_from_db(sql, db_data=client_db)
            if res_data:
                context["app_name"] = res_data
        except:
            context["app_name"] = ["error"]

        # search app name
        search_app_name = self.request.GET.get("search_app_name", None)
        server_db = {}
        try:
            if search_app_name:
                sql = "select db_slave_ip,log_db_name,record_url,app_name from gameinfo where id=%s" % search_app_name

                try:
                    res_data = self.read_data_from_db(sql, db_data=client_db)
                    if res_data:
                        data = res_data

                        server_db["db_host"] = data[0][0]
                        server_db["db_name"] = data[0][1]
                        server_db["db_port"] = "3306"
                        server_db["db_user"] = "pyj_statistics"
                        server_db["db_pass"] = "ghW78mq16cjU0iuy1EWrsdTNl"
                        server_db["pyj_url"] = data[0][2]

                except:
                    pass
        except:
            pass

        # search record
        search_record = self.request.GET.get("search_record", None)
        try:
            if search_record and server_db["db_name"]:
                sql = "select playBackNames,gameStartTime from %s where roomid=%s order by id desc" % ("u_pyj_record_log", search_record)
                try:
                    res_data = self.read_data_from_db(sql, db_data=server_db)
                    if res_data:
                        tmp = []
                        print res_data
                        for line_1 in res_data:
                            pyj_time = line_1[1]
                            pyj_data = (line_1[0])[1:-1]
                            pyj_data = pyj_data.split(",")
                            for line_2 in pyj_data:
                                tmp.append("%s:%s" % (pyj_time, line_2.strip()))
                        print tmp
                        if len(tmp[0]) > 0:
                            context["pyjrecord"] = tmp
                            context["app_name_"] = data[0][3]
                            context["roomID"] = search_record
                            context["pyj_url"] = data[0][2]
                            context["search_record"] = search_record
                        else:
                            context["404tip"] = "没有roomID或搜索的roomID没有战绩文件"
                    else:
                        context["404tip"] = "没有roomID或搜索的roomID没有战绩文件"
                except:
                    context["404tip"] = "没有roomID或搜索的roomID没有战绩文件"
        except:
            context["404tip"] = "没有roomID或搜索的roomID没有战绩文件"

        return context

    def read_data_from_db(self, sql, db_data=None):
        '''
        链接db，取回数据
        :param sql:
        :param db_data:
        :return:
        '''
        try:
            conn = pymysql.connect(db=db_data["db_name"], user=db_data["db_user"],
                                   passwd=db_data["db_pass"], host=db_data["db_host"],
                                   port=int(db_data["db_port"]),charset="utf8")
            cursor = conn.cursor()
        except Exception, e:
            print(e)
            print('数据库连接失败:%s' % e)
            return False
        try:
            cursor.execute(sql)
            data = cursor.fetchall()
        except Exception, e:
            print('数据执行失败:%s' % e)
            return False
        finally:
            cursor.close()
            conn.close()

        return data
