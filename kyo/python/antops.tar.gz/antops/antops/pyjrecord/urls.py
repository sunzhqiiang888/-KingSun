from django.conf.urls import url, include
from pyjrecord import record

urlpatterns = [
    url(r'^pyjrecord/$', record.DownLoadRecord.as_view(), name="download_reord")
]