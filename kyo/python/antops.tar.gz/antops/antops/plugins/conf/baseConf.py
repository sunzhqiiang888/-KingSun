
# db configure
db_base = {
    "HOST": "39.108.108.30",
    "PORT": 3306,
    "NAME": "napolun",
    "USER": "yw_portal_user",
    "PWD": "cMnd&^dhG$dg6",
}
