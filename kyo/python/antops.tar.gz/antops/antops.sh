#!/usr/bin/env bash
### ant.sh
####
process=4
uwsgibin=/data/www/antops/env27/bin/uwsgi
processini=/data/www/antops/antops.ini
pidfile=/tmp/uwsgi.pid

# start function
psid=$(ps aux| grep "/data/www/antops/env27/bin/uwsgi"|grep -v "grep"|wc -l)

function start(){
    if [ $psid -ge ${process} ];then
        echo "uwsgi is running..."
        exit 1
    else
        ${uwsgibin} --ini ${processini}
        echo "Start uwsgi service [OK]"
    fi
}

# stop function
function stop(){
    kill -INT $(cat ${pidfile})
    echo "Stop uwsgi is [OK]"
}

# reload function
function reload(){
    ${uwsgibin} -s reload ${processini}
    echo "Reload configure is [OK]"
}

case "$1" in
    start)
        start && exit 0
    ;;
    stop)
        stop && exit 0
    ;;
    reload)
        reload && exit 0
    ;;
    *)
        echo "Usages: bash $0 [start|stop|restart|reload]"
    ;;
esac
