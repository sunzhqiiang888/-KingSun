# -*- coding:utf-8 -*-

import sys
import os
from plugins.base import DealParameter
from plugins.git  import GitShell
from plugins.playbook import AnsiblePlaybook
from plugins.excute import ExecuteShell
from conf.conf import base_conf


def release_run(argvs):
    # ansible inventory
    ansible_inventory = base_conf["ansible_inventory"]

    # # ansible playbook default shell
    ansible_playbook_default_shell = base_conf["ansible_playbook_default_shell"]

    # git base work dir
    git_base_work = base_conf["git_base_work"]

    # 当前操作主机组的变量名称
    releases_host_group = base_conf["releases_host_group"]

    # 当前游戏程序主目录变量名称
    releases_game_dir = base_conf["releases_game_dir"]

    # 实例化参数对象
    base_obj = DealParameter(argvs, base_conf["ansible_inventory"])
    # 参数数据字典
    para_dict = base_obj.get_para_dict(base_obj.get_para())

    if para_dict:
        # 操作的方法
        action_method = para_dict["action_method"]
        if action_method == "update_game":
            # 获取真实的git工作目录
            git_work = base_obj.get_git_work(git_base_work, para_dict)
            # 实例好执行对象
            exec_obj = GitShell()
            # 获取当前执行的命令
            res_result = exec_obj.git_pull(git_work)
            # git 结果 输出
            print(res_result[-1])

            print("")
            print("yaml 配置文件语法测试")
            # 本地yml配置文件测试
            test_shell = base_conf["gs_confg_test"]
            # 本地测试test playbook命令
            test_playbook = "%s %s -i %s -e" % (ansible_playbook_default_shell, test_shell, ansible_inventory)
            # 将操作主机强制变更为local_host，ansible inventory中必须有此主机
            local_host = "local_host"
            # 实例化对象
            test_obj = AnsiblePlaybook(releases_host_group, releases_game_dir, para_dict)
            # 调用测试方法
            test_obj.create_yaml_config(test_playbook, local_host)
            test_file = base_conf["ansible_test_file"]
            # 直接语法测试，有问题报错；无问题无显示
            os.system("python -c 'import yaml,sys;yaml.safe_load(sys.stdin)' < %s" % test_file)
            print("")

            try:
                if int(res_result[0]) == 0:
                    # 重新调用初始化参数方法，生成数据，因为前面强制把主机组变为local_host
                    para_dict = base_obj.get_para_dict(base_obj.get_para())
                    print("")
                    # 检查运行端口
                    gs_check_port = base_conf["gs_check_port"]
                    playbook_shell = "%s %s -i %s -e" % (ansible_playbook_default_shell, gs_check_port, ansible_inventory)
                    update_obj = AnsiblePlaybook(releases_host_group, releases_game_dir, para_dict)
                    # 调用 检查端口方法
                    update_obj.gs_check_port(playbook_shell)
                    print("")
                    while True:
                        inc = raw_input("继续停服-备份操作/退出更新操作 [yes/no]: ")
                        if inc.lower() == "yes":

                            # ansible playbook shell
                            gs_main_stop = base_conf["gs_main_stop"]
                            playbook_shell = "%s %s -i %s -e" % (ansible_playbook_default_shell, gs_main_stop, ansible_inventory)

                            # 运行ansible-playbook命令，传递主机组，yml中的主机组变量，ansible-playbook命令

                            update_obj.update_stop_game(playbook_shell)
                            print("")
                            while True:
                                inp = raw_input("继续更新文件/退出 [yes/no]: ")
                                inp = inp.lower()
                                if inp == "yes":
                                    # ansible playbook shell
                                    gs_main_start = base_conf["gs_main_start"]
                                    playbook_shell = "%s %s -i %s -e" % (ansible_playbook_default_shell, gs_main_start, ansible_inventory)
                                    update_obj.update_start_game(playbook_shell)

                                    print("")
                                    gs_check_port = base_conf["gs_check_port"]
                                    playbook_shell = "%s %s -i %s -e" % (ansible_playbook_default_shell, gs_check_port, ansible_inventory)
                                    # 调用 检查端口方法
                                    update_obj.gs_check_port(playbook_shell)
                                    print("")

                                    break
                                elif inp.lower() == "no":
                                    sys.exit("结束退出...")

                            break
                        elif inc.lower() == "no":
                            sys.exit("退出更新...")
                else:
                    # 帮助
                    base_obj.get_help()
                    sys.exit("git pull的之势不正确，请确保git pull的之势\n")
            except:
                sys.exit("")

        elif action_method == "stop_game":
            print("")
            # 检查运行端口
            gs_check_port = base_conf["gs_check_port"]
            playbook_shell = "%s %s -i %s -e" % (ansible_playbook_default_shell, gs_check_port, ansible_inventory)
            update_obj = AnsiblePlaybook(releases_host_group, releases_game_dir, para_dict)
            # 调用 检查端口方法
            update_obj.gs_check_port(playbook_shell)
            print("")

            # 单独停服主入口文件
            stop_playbook_yml = base_conf["gs_stop"]
            while True:
                inc = raw_input("确认停服操作？ [yes/no]: ")
                if inc.lower() == "yes":
                    # ansible playbook shell
                    playbook_shell = "%s %s -i %s -e" % (ansible_playbook_default_shell, stop_playbook_yml, ansible_inventory)

                    # 实例好执行对象
                    exec_obj = ExecuteShell(releases_host_group, releases_game_dir, para_dict)
                    # 获取当前执行的命令
                    git_command = exec_obj.execute_shell()
                    git_command(playbook_shell)

                    print("")
                    gs_check_port = base_conf["gs_check_port"]
                    playbook_shell = "%s %s -i %s -e" % (
                    ansible_playbook_default_shell, gs_check_port, ansible_inventory)
                    # 调用 检查端口方法
                    update_obj.gs_check_port(playbook_shell)
                    print("")
                    break
                elif inc.lower() == "no":
                    sys.exit("退出更新...")

        elif action_method == "start_game":
            # 单独开服主入口文件
            start_playbook_yml = base_conf["gs_start"]
            while True:
                inc = raw_input("确认启动操作？ [yes/no]: ")
                if inc.lower() == "yes":
                    # ansible playbook shell
                    playbook_shell = "%s %s -i %s -e" % (ansible_playbook_default_shell, start_playbook_yml, ansible_inventory)

                    # 实例好执行对象
                    exec_obj = ExecuteShell(releases_host_group, releases_game_dir, para_dict)
                    # 获取当前执行的命令
                    git_command = exec_obj.execute_shell()
                    git_command(playbook_shell)
                    print("")
                    # 检查运行端口
                    gs_check_port = base_conf["gs_check_port"]
                    playbook_shell = "%s %s -i %s -e" % (
                    ansible_playbook_default_shell, gs_check_port, ansible_inventory)
                    update_obj = AnsiblePlaybook(releases_host_group, releases_game_dir, para_dict)
                    # 调用 检查端口方法
                    update_obj.gs_check_port(playbook_shell)
                    print("")
                    break
                elif inc.lower() == "no":
                    sys.exit("退出更新...")

        elif action_method == "update_conf":
            # 单独推送配置文件主入口
            config_playbook_yml = base_conf["gs_config"]

            print("")
            print("yaml 配置文件语法测试")
            # 本地yml配置文件测试
            test_shell = base_conf["gs_confg_test"]
            # 本地测试test playbook命令
            test_playbook = "%s %s -i %s -e" % (ansible_playbook_default_shell, test_shell, ansible_inventory)
            # 将操作主机强制变更为local_host，ansible inventory中必须有此主机
            local_host = "local_host"
            # 实例化对象
            test_obj = AnsiblePlaybook(releases_host_group, releases_game_dir, para_dict)
            # 调用测试方法
            test_obj.create_yaml_config(test_playbook, local_host)
            test_file = base_conf["ansible_test_file"]
            # 直接语法测试，有问题报错；无问题无显示
            os.system("python -c 'import yaml,sys;yaml.safe_load(sys.stdin)' < %s" % test_file)
            print("")

            while True:
                inc = raw_input("确认推送配置文件操作操作？ [yes/no]: ")
                if inc.lower() == "yes":
                    # 重新调用初始化参数方法，生成数据，因为前面强制把主机组变为local_host
                    para_dict = base_obj.get_para_dict(base_obj.get_para())
                    # ansible playbook shell
                    playbook_shell = "%s %s -i %s -e" % (ansible_playbook_default_shell, config_playbook_yml, ansible_inventory)

                    # 实例好执行对象
                    exec_obj = ExecuteShell(releases_host_group, releases_game_dir, para_dict)
                    # 获取当前执行的命令
                    git_command = exec_obj.execute_shell()
                    git_command(playbook_shell)
                    print("")
                    break
                elif inc.lower() == "no":
                    sys.exit("退出更新...")

        elif action_method == "git_pull":
            # 获取真实的git工作目录
            git_work = base_obj.get_git_work(git_base_work, para_dict)
            # 实例好执行对象
            exec_obj = ExecuteShell(releases_host_group, releases_game_dir, para_dict)
            # 获取当前执行的命令
            git_command = exec_obj.execute_shell()
            res_result = git_command(git_work)
            for res_line in res_result:
                print(res_line)

        elif action_method == "init_env":
            while True:
                print("")
                inc = raw_input("是否确认初始化主机组 [ %s ] 发布环境？ [yes/no:] " % para_dict["action_host"])
                if inc.lower() == "yes":
                    gs_init_env = base_conf["gs_init_env"]
                    # ansible playbook shell
                    init_playbook_shell = "%s %s -i %s -e" % (ansible_playbook_default_shell, gs_init_env, ansible_inventory)
                    # 实例好执行对象
                    exec_obj = ExecuteShell(releases_host_group, releases_game_dir, para_dict)
                    # 获取当前执行的命令
                    git_command = exec_obj.execute_shell()
                    git_command(init_playbook_shell)
                    print("")
                    break

        else:
            base_obj.get_help()
            sys.exit("不存在的操作方法 === [ %s ]\n" % action_method)
