#!/usr/bin/env python
# -*- cofing:utf-8 -*-

import sys
import os

base_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append(base_dir)

if __name__ == "__main__":
    from core import main
    main.release_run(sys.argv)
