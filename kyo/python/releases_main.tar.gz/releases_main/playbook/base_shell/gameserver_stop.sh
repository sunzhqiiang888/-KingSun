#!/usr/bin/env bash
######
#   用户停服
#   备份相关文件 deploy  lib systemConfig.yml
######

# /data/jiangsu_region_game/game
server_name=$1
date_=$(date +%Y-%m-%d_%H%M%S)
data_backup="/data/backup"

[ ! -d $data_backup ] && mkdir $data_backup

if [ -d "/data/game/$server_name" ];then
    cd /data/game/$server_name
    if [ -d 'dsqp' ] ;then 
        dir_='dsqp'
    elif [ -d 'router'];then 
        dir_='router'
    else 
        dir_='center'
    fi
else
    echo "/data/game/$server_name not exist"
fi

function quit_(){
    echo "$(date +%Y-%m-%d_%H:%M:%S) ${server_name}"
    exit 1
}

function stop_gs_server(){
     cd /data/game/$server_name/$dir_ && ./run.sh stop
}

function checkpid() {
    javaps=`ps -ef |grep "/data/game/${server_name}/$dir_/lib" | grep -v grep |awk '{print $2}'`
    if [ -n "$javaps" ]; then
        psid=`echo $javaps | awk '{print $1}'`
    else
        psid=0
    fi
}

function check_gs_status(){
     checkpid 
     if [ $psid -ne 0 ];  then
         echo "$server_name is running! (pid=$psid)"
         quit_ "$server_name is running!"
     else
         echo "$server_name is not running"
     fi
}

function backup_file(){
    mkdir -p $data_backup/$server_name/$date_
    cd /data/game/$server_name
    cp -r $dir_/deploy $data_backup/$server_name/$date_/ && cp -r $dir_/lib $data_backup/$server_name/$date_/
    [ -f $dir_/systemConfig.yml ] && cp -r $dir_/*.yml $data_backup/$server_name/$date_/
}

function clean_old_bakcup(){
    # cd $data_backup/$server_name/ && ls ./ | grep -v "$(ls ./ -1tr|sort -rn|head -n3)" | xargs rm -rf
    cd $data_backup/$server_name/ && find . -type d -mtime +7 |xargs -i rm -rf {}
}

function check_backup(){
    result=$(ls $data_backup/$server_name/$date_/ | wc -l)
    if [ $resule == 0 ];then
        quit_ "$data_backup/$server_name/$date_ is backup fail"
    else
       echo "bakcup is ok "
    fi
}

stop_gs_server
check_gs_status
backup_file
check_backup
clean_old_bakcup
