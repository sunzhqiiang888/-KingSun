#!/usr/bin/env bash

server_name=$1

if [ -d "/data/game/$server_name" ];then
    cd /data/game/$server_name
    if [ -d 'dsqp' ] ;then
        dir_='dsqp'
    elif [ -d 'router'];then
        dir_='router'
    else
        dir_='center'
    fi
else
    echo "/data/game/$server_name not exist"
fi

function quit_(){
    echo "$(date +%Y-%m-%d_%H:%M:%S) $1"
    exit 1
}

function start_gs_server()  {
    cd /data/game/$server_name/$dir_ && ./run.sh start
}

function checkpid() {
    javaps=`ps -ef |grep "/data/game/${server_name}/$dir_/lib" | grep -v grep |awk '{print $2}'`
    if [ -n "$javaps" ]; then
        psid=`echo $javaps | awk '{print $1}'`
    else
        psid=0
    fi
}

function check_gs_status(){
     sleep 3
     checkpid
     if [ $psid -ne 0 ];  then
         echo "$server_name is running! (pid=$psid)"
     else
         echo "$server_name is not running"
         quit_ "$server_name is running!"
     fi
}

start_gs_server
check_gs_status