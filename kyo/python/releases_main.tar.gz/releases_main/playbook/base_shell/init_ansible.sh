#!/usr/bin/env bash
###################
# ansible运行之前需要初始化一些环境
# 比如：
#    安装rsync
#    远程执行的脚本目录
#    复制脚本到远程目录
#    
#    必须cd /etc/ansible/playbook 执行
##################

# 需要执行的主机组/主机，跟ansible的inventory有关
# server_name=jiangsu_region_game 
server_name=$1

# 远程服务器游戏程序根目录
remote_dir="/data/game"

# 远程脚本存放目录
script_data="/data/scripts/ansible"

# 停服和备份脚本
stop_script="gameserver_stop.sh"

# 开服脚本
start_script="gameserver_start.sh"

# run.sh 脚本
run_script="run.sh"

# 安装rsync模块
ansible $server_name -m shell -a "yum -y install rsync"

# 创建远程脚本目录
ansible $server_name -m shell -a  "mkdir -p ${script_data}"
ansible $server_name -m shell -a  "mkdir -p ${remote_dir}/${server_name}/dsqp/{logs,deploy}"
ansible $server_name -m shell -a  "mkdir -p ${remote_dir}/${server_name}/dsqp/fileData/{gameZip,headimg,images,log,pyjrecord}"

# 同步脚本到远程目录，并赋予执行权限
ansible $server_name -m copy -a "src=${stop_script} dest=${script_data} mode=755"
ansible $server_name -m copy -a "src=${start_script} dest=${script_data} mode=755"
ansible $server_name -m template -a "src=${run_script} dest=${remote_dir}/${server_name}/dsqp/ mode=755"

# 查看结果
ansible $server_name -m shell -a "ls -l ${script_data}"