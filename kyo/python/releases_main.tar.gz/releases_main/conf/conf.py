# -*- coding:utf-8 -*-

import os

base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

base_conf = {
    # ansible playbook default shell
    "ansible_playbook_default_shell": "/usr/bin/ansible-playbook",

    # ansible release inventory file
    "ansible_inventory" : "%s/conf/releases_hosts" % base_dir,

    # 当前操作主机组的变量名称 在 yml中 - releases_hosts: "{{ gs_host }}"
    "releases_host_group": "gs_host",

    # 当前游戏程序主目录变量名称 - vars/{{ gs_git_game_dir }}/varsgs.yml 多个地方使用到
    "releases_game_dir": "gs_git_game_dir",

    # git base work dir
    "git_base_work": "/data/upload/templates",

    # ansible gs_main_stop playbook
    "gs_main_stop": "%s/playbook/%s.yml" % (base_dir, "gs_main_stop"),

    # ansible gs_main_start playbook
    "gs_main_start": "%s/playbook/%s.yml" % (base_dir, "gs_main_start"),

    # ansible gs_config playbook
    "gs_config": "%s/playbook/others/%s.yml" % (base_dir, "gs_config"),

    # ansible gs_stop playbook
    "gs_stop": "%s/playbook/others/%s.yml" % (base_dir, "gs_stop"),

    # ansible gs_start playbook
    "gs_start": "%s/playbook/others/%s.yml" % (base_dir, "gs_start"),

    # ansible gs_confg_test playbook
    "gs_confg_test": "%s/playbook/others/%s.yml" % (base_dir, "gs_config_test"),

    # ansible check game port shell
    "gs_check_port": "%s/playbook/others/%s.yml" % (base_dir, "gs_check_port"),

    # test file
    "ansible_test_file": "%s/playbook/files/%s.yml" % (base_dir, "systemConfig"),

    # ansible gs_init_env playbook
    "gs_init_env": "%s/playbook/others/%s.yml" % (base_dir, "gs_init_env"),

}
