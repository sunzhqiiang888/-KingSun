# -*- coding:utf-8 -*-

import sys

from git import GitShell
from playbook import AnsiblePlaybook
from base import DealParameter


class ExecuteShell(AnsiblePlaybook, GitShell):

    def execute_shell(self):
        if self.para_dict:
            if hasattr(self, self.para_dict["action_method"]):
                return getattr(self, self.para_dict["action_method"])
            else:
                DealParameter.get_help()
                sys.exit("不存在的操作方法")
        else:
            sys.exit("请确认para_dict参数正确之势")