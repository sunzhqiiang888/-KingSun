# -*- coding:utf-8 -*-

import os
import sys


class AnsiblePlaybook(object):
    def __init__(self, group_extra_vars,template_dir, para_dict):

        self.group_extra_vars = group_extra_vars
        self.template_dir = template_dir
        self.para_dict = para_dict


    def return_commands(self, playbook_shell, template_dir=None):
        if playbook_shell and self.template_dir and self.group_extra_vars and self.para_dict:
            if template_dir:
                action_host = self.para_dict["action_host"]
                print('%s "%s=%s %s=%s"' % (playbook_shell,self.group_extra_vars,
                                            action_host, self.template_dir,template_dir))
                return ('%s "%s=%s %s=%s"' % (playbook_shell, self.group_extra_vars,
                                                action_host, self.template_dir, template_dir))
            else:
                action_host = self.para_dict["action_host"]
                print('%s "%s=%s %s=%s"' % (playbook_shell, self.group_extra_vars,
                                            action_host, self.template_dir, action_host))
                return ('%s "%s=%s %s=%s"' % (playbook_shell, self.group_extra_vars,
                                              action_host, self.template_dir, action_host))

        else:
            sys.exit("运行stop_game命令，请确保参数正确")

    def stop_game(self, playbook_shell):

        os.system(self.return_commands(playbook_shell))

    def start_game(self, playbook_shell):

        os.system(self.return_commands(playbook_shell))

    def update_conf(self, playbook_shell):

        os.system(self.return_commands(playbook_shell))

    def update_stop_game(self, stop_shell):

        os.system(self.return_commands(stop_shell))

    def update_start_game(self, start_shell):

        os.system(self.return_commands(start_shell))

    def create_yaml_config(self, test_shell, local_host):

        template_dir = self.para_dict["action_host"]
        self.para_dict["action_host"] = local_host
        os.system(self.return_commands(test_shell, template_dir))

    def gs_check_port(self, gs_check_shell):

        os.system(self.return_commands(gs_check_shell))

    def init_env(self, gs_init_shell):

        os.system(self.return_commands(gs_init_shell))
