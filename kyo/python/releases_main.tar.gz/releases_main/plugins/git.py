# -*- coding:utf-8 -*-

import commands

class GitShell(object):

    # 处理git pull 命令返回状态码和输出结果
    def git_pull(self, git_home):
        if git_home:
            #return os.system("cd %s && git pull" % self.git_home)
            print("cd %s && git pull" % git_home)
            return commands.getstatusoutput("cd %s && git pull" % git_home)