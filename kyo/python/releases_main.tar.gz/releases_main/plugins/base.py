# -*- coding:utf-8 -*-

import sys
import os


class DealParameter(object):
    def __init__(self, argvs=None, inventory=None):
        self.argv = argvs
        self.inventory = inventory

    # 帮助手册
    @classmethod
    def get_help(cls):

        msg = '''
            ------------ 绝对路径使用脚本 ----------
            主机组信息，请参考ansible inventory\n

            1、版本更新\t\t\t Usage: python xxx.py update_game [需要执行操作的主机组]
                    \t\t\t      说明：\033[32m 包含{ git_pull stop_game start_game update_conf }\033[0m
                    \t\t\t      单个游戏或多个游戏都是根据主机来匹配的，所以最终的控制都是在ansible inventory里

            2、推送配置\t\t\t Usage: python xxx.py update_conf [需要执行操作的主机组]

            3、关闭游戏服\t\t Usage: python xxx.py stop_game [需要执行操作的主机组]

            4、启动游戏服\t\t Usage: python xxx.py start_game [需要执行操作的主机组]

            5、拉取最新代码\t\t Usage: python xxx.py git_pull [需要执行操作的主机组]
            
            6、初始化环境\t\t Usage: python xxx.py init_env [需要执行操作的主机组]

        '''
        print(msg)

    # 处理sys.argv参数, 返回参数列表
    def get_para(self):
        if len(self.argv) == 3:
            return self.argv[1:3]
        else:
            self.get_help()
            sys.exit(" 请确认参数 %s" % self.argv[1:])

    # about ansible 确认absible inventory真实性
    def get_inventory(self):
        inventory_tag = "yes" if (os.path.exists(self.inventory)
                                  and os.path.isfile(self.inventory)) else "no"
        return inventory_tag

    # about ansible  确认传递的host组是否真实存在
    def get_actual_host(self, action_host):
        str_host = "[%s]" % action_host
        if action_host and (self.get_inventory()).lower() == "yes":
            with open(self.inventory, 'r') as invf:
                for line in invf:
                    if line.strip() == str_host:
                        result = action_host
                        break
                    else:
                        result = ""
            return result
        else:
            sys.exit("get_actual_host 处理主机组信息出错，缺少主机组或invertoy文件不存在")

    # 处理所有参数为字典类型
    def get_para_dict(self, data_para):
        data = {}

        if len(data_para) == 2:
            if self.get_actual_host(data_para[1]):
                data["action_host"] = data_para[1]
                data["action_method"] = data_para[0]
            else:
                sys.exit("[ %s ]主机组不存在主机列表中，详细信息请查看ansible inventory文件" % data_para[1])
        else:
            self.get_help()
            sys.exit("请确认运行程序参数参数")
        return data

    # about git 确认git工作目录的真实性
    def get_actual_git_dir(self, git_work):
        actual_git_work = git_work if os.path.exists(git_work) and os.path.isdir(git_work) else ""
        return actual_git_work

    # about git
    def get_git_work(self, base_dir, data_para):
        if data_para:
            action_host = (data_para["action_host"])
            if len(data_para) == 2:
                git_work = "%s/%s" % (base_dir, action_host)
                actual_work = self.get_actual_git_dir(git_work)
                if actual_work:
                    return actual_work
                else:
                    sys.exit("get_git_work 退出原因：没有git的工作目录: %s " % git_work)
            else:
                sys.exit("get_git_work 退出原因：data_para缺少参数")
        else:
            sys.exit("get_git_work 退出原因：data_para为空")
